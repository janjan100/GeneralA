const carousel = new bootstrap.Carousel('#myCarousel');
// for carousel pp sliding

const myCarousel = document.getElementById('myCarousel')

myCarousel.addEventListener('slide.bs.carousel', event => {
  // do something...
})
